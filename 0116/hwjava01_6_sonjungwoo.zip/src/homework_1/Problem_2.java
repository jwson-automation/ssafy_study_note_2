package homework_1;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Problem_2 {
	public static void main(String[] args) throws IOException {
		
//		입력값 받아오기
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st =  new StringTokenizer(br.readLine());
		int number1 = Integer.parseInt(st.nextToken());
		int number2 = Integer.parseInt(st.nextToken());
		
		
		
//		곱과 몫 구하기
		int multiple = number1 * number2 ; 
		int remain = number1 / number2 ;
		
//		출력하기
		System.out.print("곱=");
		System.out.println(multiple);
		System.out.print("몫=");
		System.out.println(remain);
	}

}
