package homework_1;

import java.io.IOException;
//import java.io.BufferedReader;
//import java.io.InputStreamReader;
//import java.util.StringTokenizer;

public class Problem_1 {
	public static void main(String[] args) throws IOException {
		
//		파이 구하는 공식
		double sum = 0;
		for(int i=0; i<100; i++){
			sum += Math.pow(-1,i)/((2*i+1)*Math.pow(3,i));
			}
		double Pi = Math.sqrt(12)*sum;
		
//		입력값 받아오기
//		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//		StringTokenizer st =  new StringTokenizer(br.readLine());
//		double input = Double.parseDouble(st.nextToken());
		int input = 5;
		
		
//		원주율 계산하기
		double answer = input * input * Pi;	 
		System.out.print("반지름이 5Cm인 원의 넓이는");
		System.out.print(answer);
		System.out.print("Cm2입니다.");
		
	}

}
