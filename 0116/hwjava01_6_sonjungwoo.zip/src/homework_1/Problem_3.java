package homework_1;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Problem_3 {
	public static void main(String[] args) throws IOException {
		
//		입력값 받아오기
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st =  new StringTokenizer(br.readLine());
		int height = Integer.parseInt(st.nextToken());
		int weight = Integer.parseInt(st.nextToken());
		
		
		
//		비만 수치 계산하기
		int bmi = weight + 100 - height;
		
//		출력하기
		System.out.print("비만수치는 ");
		System.out.print(bmi);
		System.out.println("입니다.");
		
//		비만이군요 계산하기 
		if(bmi > 0) System.out.println("당신은 비만이군요");
	}

}
